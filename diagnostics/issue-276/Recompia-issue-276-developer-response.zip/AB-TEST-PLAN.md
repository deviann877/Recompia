# Prepared protocol; not yet run

Use only the existing custom candidate runtime in the isolated Testing install.
Do not enable deferred readback in an old official runtime or change Gaming.
No game should be launched automatically. The user performs each route and
reports completion; collect evidence and stop at each checkpoint.

## Prepare when the user is ready

1. Close Testing normally. Back up fresh Testing saves, INIs, current shortcut
   options and logs. Verify the candidate DLL/map hashes against the build record.
2. Remove LSFG options from Testing only and reload Steam's shortcut safely;
   respect the user's preference for a Deck reboot over restarting Steam. Confirm
   the effective running command/environment no longer enables LSFG. Do not rely
   solely on the absence of LSFG messages in pkp.log.
3. Set the game's internal frame limit to 45 in `controls.ini`; VSync off and
   fps_snap false. Keep the same display refresh, resolution, graphics settings,
   power/TDP and clock policy in every run. Record Steam's performance limiter
   state; avoid a second limiter by disabling it consistently for these tests.
4. Keep all diagnostic settings identical across A and B. Use:

```ini
[nvn]
readback_defer_texture = 286
readback_log = true

[diag]
hitch_log = true
hitch_summary_s = 10
hitch_ms = 35
```

   Merge these keys into existing sections; do not replace the whole INI. The
   35 ms detailed threshold can expose doubled ~44 ms frames that a 50 ms
   threshold misses. Existing detailed logging is rate-limited, so retain the
   ten-second summaries too. Do not use the old intrusive stack sampler.
5. Confirm target 286 still has the expected RGBA8_SRGB 30x16x1 shape and that B
   actually logs deferred reads/pending-to-complete progress. If the ID changed,
   stop to identify it and restart a consistently configured pair.

## Alternating runs

Order: A1, B1, A2, B2, A3, B3.

- A: `readback_defer=false` in the custom candidate.
- B: `readback_defer=true` in the same custom candidate.
- Keep selector 286, logging, submit_batch and all other settings unchanged.
- Fully close/restart between runs; these options are read at startup.
- Use the same save, starting position, camera route and walking route. Avoid
  saving during the measured route so later runs start from equivalent state.
- Allow a consistent 60-second warmup, then measure at least 120 seconds of the
  same route. Record the actual start/end runtime timestamps and any loading or
  menu intervals; do not silently drop them from the full log.
- Verify `play: frame cap 45` at startup, no subsequent cap change, correct
  experiment status and no LSFG for every measured run.
- At each normal exit, copy the full pkp.log plus configuration and shortcut/
  environment verification BEFORE the next launch rotates logs. Give each run
  an immutable name and SHA256 hash. Keep raw evidence private and sanitize only
  identifiers for sharing, retaining every diagnostic line.

Compare ten-second mean FPS, 1% low, worst frame and count above 2x median, plus
detailed hitch/readback timings and the user's observed periodicity. Report each
run and the measured boundaries rather than treating pooled different scenes
as a controlled benchmark. Built-in summaries are not a full per-frame trace;
record that limitation if the developer needs finer correlation.

## Longer correctness coverage, separately labelled

On copied Testing saves, after the matched route runs:

- At least 15 minutes of normal gameplay with B enabled.
- Repeatedly open/close menus and maps, change areas, enter/leave interiors and
  repeat the transitions that previously stressed the game.
- Save normally, close, restart and load; verify latest inventory, building and
  quest progress. Waking at home alone is not a save-failure criterion.
- Record visible defects, freezes, failures and actual actions. Do not infer
  coverage merely because the log spans a long time.
- Preserve all logs, including failures. Stop on a freeze/regression for capture
  before recovery; do not automatically kill processes or reboot.
- After collecting matched diagnostic runs, repeat comparison with timing/poll
  logging off to check instrumentation effects. Keep this distinct from the
  requested logged A/B data. LSFG testing is a separate phase afterwards.
