Thanks — I have prepared the exact patch against `59607eccafa9d9565d1f8a76230c4d58271117f2` and the preserved off/on logs. The runtime changes are also in #358.

The attachment includes the original patch and a portable Git-generated copy. I verified the portable patch against the original source blobs from that exact commit and compared the result with the hardware-tested candidate; the runtime code matches after newline normalization.

For the environment name: we set the selector through the INI, not an environment override:

```ini
[nvn]
readback_defer_texture = 286
```

The equivalent environment variable is **`NXRT_NVN_READBACK_DEFER_TEXTURE=286`**. It is read by `config_get_int("nvn", "readback_defer_texture", 0)` using the standard config environment-name mapping. Environment overrides take precedence; a full restart is required because the readback configuration is static. The related keys are `NXRT_NVN_READBACK_DEFER` and `NXRT_NVN_READBACK_LOG`.

The ZIP contains:

- The entire preserved candidate-OFF log (~219 seconds), with all frame-time summaries. Readback timing logging was off for that run.
- An entire later candidate-ON log (~647 seconds) from before LSFG was added, with readback logging and all frame-time summaries.
- The initial ~239-second ON snapshot previously reported, explicitly marked as a snapshot captured while running.
- Patch verification, hashes, a log index and the proposed repeated A/B protocol.

Only home-path prefixes and audio-device UUIDs were redacted from the logs; no log lines, loading stalls, warnings or hitches were removed.

One correction to how these results should be interpreted: **these are preliminary observational runs, not the repeated matched-cap A/B you requested**. The OFF log reports internal cap 0 and has no later internal cap-change message. The longer ON log starts at cap 0 and changes to 45 at t=106.367628 seconds. The prior effective external cap was not captured, and readback logging differed between the original OFF and ON runs. We should not infer a controlled capped improvement from these files.

The repeated test is prepared as A1/B1/A2/B2/A3/B3 using the same custom candidate DLL, a verified 45 FPS internal cap, no LSFG, identical diagnostics/settings, and a full restart between OFF and ON. Each run will preserve its full log before the next launch. Longer menu/transition/save-load coverage will be recorded separately. This test has not been completed yet.

Agreed that the 0.02 ms values are CPU readback-call durations, not GPU completion or whole-frame timings. We will keep the previous official deferred implementation disabled; the proposed A/B only toggles our candidate's experimental path.
